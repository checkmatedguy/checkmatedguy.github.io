# Home Page Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/checkmatedguy/pen/LYwpddL](https://codepen.io/checkmatedguy/pen/LYwpddL).

